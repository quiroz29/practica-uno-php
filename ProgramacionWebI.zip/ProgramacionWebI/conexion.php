<?php
    $host = "localhost";
    $usuario = "root";
    $password = "";
    $db = "db_prograweb2025";
    $conexion = new mysqli($host,$usuario,$password,$db);
    if($conexion == null){
        echo "error de conexion, revisa los puntos/comas";
    }else{
        echo "hay conexion";
    }
?>