<?php 
    require_once "conexion.php";
    
    $nombres = $_POST['nomp'];
    $apellido = $_POST['apep'];
    $domicilio = $_POST['domip'];
    $sql = "INSERT INTO personas (nombres,apellidos,domicilio) VALUE ('$nombres','$apellido','$domicilio');"; 
    #$sql = "INSERT INTO personas (nombres,apellidos,domicilio) VALUE ('rafael','siles','plan 666k');"; 
    $conexion->query($sql);
    header('location: index.html');
?>
